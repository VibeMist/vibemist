# Gym Fresh - VibeMist Drop 1 E-commerce Platform

## Overview

This is a Flask-based e-commerce web application for selling "VibeMist Drop 1," a premium fitness product. The application is designed as a mobile-first, single-product landing page with integrated payment processing through Razorpay and order management capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Traditional server-side rendered Flask application with Jinja2 templates
- **Styling**: Custom CSS with modern gradient design and mobile-first responsive layout
- **JavaScript**: Vanilla JavaScript for client-side interactions (no frameworks)
- **Design Pattern**: Single Product Landing Page (SPLP) optimized for conversions

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Database ORM**: SQLAlchemy with Flask-SQLAlchemy extension
- **Architecture Pattern**: Modular Flask application with separate files for models, routes, and app configuration
- **Session Management**: Flask sessions for order data persistence during checkout flow

### Data Storage
- **Development Database**: SQLite (default fallback)
- **Production Database**: Configurable via DATABASE_URL environment variable
- **ORM**: SQLAlchemy with DeclarativeBase for modern SQLAlchemy 2.0+ compatibility

## Key Components

### 1. Application Structure
- `app.py`: Core Flask application setup and configuration
- `main.py`: Application entry point for development server
- `models.py`: Database models definition
- `routes.py`: URL routing and view functions
- `templates/`: Jinja2 HTML templates
- `static/`: CSS and JavaScript assets

### 2. Database Models
- **Order Model**: Comprehensive order tracking with customer information, shipping address, product details, payment status, and timestamps
- **Order ID Generation**: Auto-generated 8-character uppercase order IDs using UUID

### 3. Payment Integration
- **Payment Gateway**: Razorpay integration for secure payment processing
- **Payment Methods**: Online payments via Razorpay and Cash on Delivery (COD)
- **Order Status Tracking**: Status progression from pending → paid → shipped → delivered

### 4. User Journey Flow
1. Landing page with product showcase
2. Order initiation
3. Checkout form with customer details and shipping address
4. Payment selection (Razorpay or COD)
5. Order confirmation and tracking

## Data Flow

### Order Processing Flow
1. **Product Display**: User views product on landing page (`/`)
2. **Order Initiation**: User clicks "Order Now" (`/order` → redirects to `/checkout`)
3. **Checkout**: User fills form with personal and shipping details (`/checkout` POST)
4. **Payment**: User selects payment method and completes transaction (`/payment`)
5. **Confirmation**: Order is created and user receives confirmation (`/confirmation`)

### Session Management
- Order data is temporarily stored in Flask sessions during checkout process
- Session data is cleared after successful order creation
- Session secret key configurable via environment variable

### Database Interactions
- Order creation with automatic timestamp generation
- Order status updates throughout fulfillment process
- Order retrieval for confirmation and tracking pages

## External Dependencies

### Payment Processing
- **Razorpay**: Primary payment gateway integration
- **Configuration**: Requires `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` environment variables
- **Fallback**: Test credentials provided for development

### Email Integration
- **EmailJS**: Client-side email service integration (appears to be configured but not fully implemented)
- **Purpose**: Likely for order confirmations and customer communications

### Third-party Libraries
- **Flask**: Web framework
- **SQLAlchemy**: Database ORM
- **Werkzeug**: WSGI utilities and proxy fix for deployment
- **Razorpay Python SDK**: Payment processing

## Deployment Strategy

### Environment Configuration
- **Database**: Configurable via `DATABASE_URL` environment variable
- **Session Security**: `SESSION_SECRET` environment variable for session encryption
- **Payment Gateway**: Razorpay credentials via environment variables

### Production Considerations
- **Proxy Support**: ProxyFix middleware configured for reverse proxy deployments
- **Database Connection**: Pool settings configured for production database connections
- **Logging**: Debug logging enabled (should be adjusted for production)

### Hosting Readiness
- **WSGI Compatible**: Can be deployed on any WSGI-compatible server
- **Port Configuration**: Default development server runs on port 5000
- **Static Assets**: Organized in standard Flask static folder structure

### Security Features
- Session-based order data management
- Environment variable configuration for sensitive data
- Secure payment processing through Razorpay

The application follows Flask best practices with clear separation of concerns, making it maintainable and scalable for a single-product e-commerce solution.