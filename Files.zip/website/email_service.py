"""
Alternative email service for order confirmations
This provides multiple email solutions in case EmailJS fails
"""
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import logging

def send_simple_email(order_data, customer_email):
    """
    Simple email sending function - requires SMTP configuration
    For now, this creates email content that can be copied and sent manually
    """
    
    # Create email content
    email_content = create_email_template(order_data)
    
    # Log the email content for manual sending
    logging.info("="*50)
    logging.info("ORDER CONFIRMATION EMAIL TO SEND")
    logging.info("="*50)
    logging.info(f"To: {customer_email}")
    logging.info(f"Subject: Order Confirmation - VibeMist Drop 1 (Order #{order_data['order_id']})")
    logging.info("Content:")
    logging.info(email_content)
    logging.info("="*50)
    
    # You can manually copy this content and send via Gmail/Outlook
    return email_content

def create_email_template(order_data):
    """Create professional email template for order confirmation"""
    
    payment_method = order_data.get('payment_method', 'online')
    payment_status = 'Confirmed' if payment_method == 'online' else 'Cash on Delivery'
    
    email_content = f"""
Dear {order_data['customer_name']},

Thank you for your order from VibeMist! Your order has been successfully placed.

ORDER DETAILS:
• Order ID: {order_data['order_id']}
• Product: {order_data.get('product_name', 'VibeMist Drop 1')}
• Quantity: {order_data.get('quantity', 1)}
• Total Amount: ₹{order_data.get('price', 0):.2f}
• Payment Method: {payment_method.upper()}
• Payment Status: {payment_status}

SHIPPING ADDRESS:
{order_data['customer_name']}
{order_data['address_line_1']}
{order_data.get('address_line_2', '') + ' ' if order_data.get('address_line_2') else ''}{order_data['city']}, {order_data['state']} {order_data['pincode']}
{order_data.get('country', 'India')}

CONTACT INFORMATION:
• Email: {order_data['customer_email']}
• Phone: {order_data.get('customer_phone', 'Not provided')}

Your order will be processed within 24 hours. You can track your order status at any time.

For any questions or concerns, please contact us:
• Email: vibemiststore@gmail.com
• Instagram: @vibemist

Thank you for choosing VibeMist!

Best regards,
VibeMist Team
"Smells like hustle. Priced like water. 💪"

---
This is an automated email confirmation. Please do not reply to this email.
    """
    
    return email_content.strip()

def get_whatsapp_message(order_data):
    """Create WhatsApp message template for order confirmation"""
    
    message = f"""
🎉 *VibeMist Order Confirmed!*

Order ID: *{order_data['order_id']}*
Product: VibeMist Drop 1
Quantity: {order_data.get('quantity', 1)}
Total: ₹{order_data.get('price', 0):.2f}

Payment: {order_data.get('payment_method', 'online').upper()}

Shipping to:
{order_data['customer_name']}
{order_data['address_line_1']}
{order_data['city']}, {order_data['state']}

We'll process your order within 24 hours!

Track your order: [Your website URL]/track/{order_data['order_id']}

Questions? Contact us at vibemiststore@gmail.com

*VibeMist Team* 💪
    """
    
    return message.strip()

# Alternative: Create email draft that can be copied
def create_gmail_draft_link(order_data, customer_email):
    """Create a Gmail compose link with pre-filled email content"""
    
    subject = f"Order Confirmation - VibeMist Drop 1 (Order #{order_data['order_id']})"
    body = create_email_template(order_data)
    
    # URL encode the content for Gmail compose link
    import urllib.parse
    
    subject_encoded = urllib.parse.quote(subject)
    body_encoded = urllib.parse.quote(body)
    to_encoded = urllib.parse.quote(customer_email)
    
    gmail_link = f"https://mail.google.com/mail/?view=cm&fs=1&to={to_encoded}&su={subject_encoded}&body={body_encoded}"
    
    return gmail_link

if __name__ == "__main__":
    # Test the email template
    test_order = {
        'order_id': 'TEST123',
        'customer_name': 'Test Customer',
        'customer_email': 'test@example.com',
        'customer_phone': '9876543210',
        'address_line_1': 'Test Address Line 1',
        'city': 'Test City',
        'state': 'Test State',
        'pincode': '123456',
        'product_name': 'VibeMist Drop 1',
        'quantity': 1,
        'price': 179.0,
        'payment_method': 'online'
    }
    
    email_content = send_simple_email(test_order, test_order['customer_email'])
    print("Email template created successfully!")