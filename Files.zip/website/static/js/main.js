// Main JavaScript functionality for Gym Fresh website

// Initialize EmailJS
(function() {
    // Check for new EmailJS v4 API first, then fallback to old version
    if (typeof emailjs !== 'undefined') {
        try {
            emailjs.init({
                publicKey: "mIMnoktAX9UMVX0kS"
            });
            console.log('EmailJS v4 initialized successfully');
        } catch (e) {
            // Fallback to old API
            emailjs.init("mIMnoktAX9UMVX0kS");
            console.log('EmailJS v3 initialized successfully');
        }
    } else {
        console.log('EmailJS not loaded - email functionality disabled');
    }
})();

// Music player functionality
let isPlaying = false;
let audioContext;
let audioElement;

function toggleMusic() {
    const musicPlayer = document.querySelector('.music-player');
    
    if (!isPlaying) {
        // Start playing music
        if (!audioElement) {
            // Create audio element for background music
            audioElement = new Audio();
            audioElement.loop = true;
            audioElement.volume = 0.3;
            
            // Add a simple background tone using Web Audio API
            if (!audioContext) {
                audioContext = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioContext.createOscillator();
                const gainNode = audioContext.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(audioContext.destination);
                
                oscillator.frequency.setValueAtTime(220, audioContext.currentTime);
                oscillator.type = 'sine';
                gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
                
                oscillator.start();
                
                setTimeout(() => {
                    oscillator.stop();
                }, 30000); // Play for 30 seconds
            }
        }
        
        musicPlayer.classList.add('playing');
        isPlaying = true;
    } else {
        // Stop playing music
        if (audioElement) {
            audioElement.pause();
        }
        if (audioContext) {
            audioContext.suspend();
        }
        
        musicPlayer.classList.remove('playing');
        isPlaying = false;
    }
}

// Copy UPI ID functionality
function copyUPIId() {
    const upiId = 'harshilgarg31@oksbi';
    
    if (navigator.clipboard) {
        navigator.clipboard.writeText(upiId).then(() => {
            showFlashMessage('UPI ID copied to clipboard!', 'success');
        }).catch(() => {
            fallbackCopyTextToClipboard(upiId);
        });
    } else {
        fallbackCopyTextToClipboard(upiId);
    }
}

function fallbackCopyTextToClipboard(text) {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    
    // Avoid scrolling to bottom
    textArea.style.top = "0";
    textArea.style.left = "0";
    textArea.style.position = "fixed";
    
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
        const successful = document.execCommand('copy');
        if (successful) {
            showFlashMessage('UPI ID copied to clipboard!', 'success');
        } else {
            showFlashMessage('Failed to copy UPI ID', 'error');
        }
    } catch (err) {
        showFlashMessage('Failed to copy UPI ID', 'error');
    }
    
    document.body.removeChild(textArea);
}

// Flash message functionality
function showFlashMessage(message, type = 'info') {
    const flashContainer = document.querySelector('.flash-messages') || createFlashContainer();
    
    const flashMessage = document.createElement('div');
    flashMessage.className = `flash-message flash-${type}`;
    flashMessage.textContent = message;
    
    flashContainer.appendChild(flashMessage);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (flashMessage.parentNode) {
            flashMessage.parentNode.removeChild(flashMessage);
        }
    }, 5000);
}

function createFlashContainer() {
    const container = document.createElement('div');
    container.className = 'flash-messages';
    document.body.appendChild(container);
    return container;
}

// Send confirmation email function
function sendConfirmationEmail() {
    if (typeof emailjs === 'undefined') {
        showFlashMessage('Email service not available', 'error');
        return;
    }
    
    if (typeof window.orderData === 'undefined') {
        showFlashMessage('Order data not found', 'error');
        return;
    }
    
    const templateParams = {
        to_email: window.orderData.customer_email,
        customer_name: window.orderData.customer_name,
        order_id: window.orderData.order_id,
        product_name: window.orderData.product_name,
        quantity: window.orderData.quantity,
        total_amount: window.orderData.price,
        payment_method: window.orderData.payment_method || 'Online',
        shipping_address: `${window.orderData.address_line_1}, ${window.orderData.city}, ${window.orderData.state} ${window.orderData.pincode}`,
        business_email: 'vibemiststore@gmail.com',
        customer_phone: window.orderData.customer_phone
    };
    
    const serviceId = 'service_t26fwjh';
    const templateId = 'template_dc8mx5l';
    
    emailjs.send(serviceId, templateId, templateParams)
        .then(function(response) {
            showFlashMessage('Confirmation email sent successfully!', 'success');
        }, function(error) {
            console.error('Email send failed:', error);
            showFlashMessage('Failed to send confirmation email', 'error');
        });
}

// Smooth scrolling for anchor links
document.addEventListener('DOMContentLoaded', function() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Auto-hide flash messages
    const flashMessages = document.querySelectorAll('.flash-message');
    flashMessages.forEach(message => {
        setTimeout(() => {
            if (message.parentNode) {
                message.style.animation = 'slideOut 0.3s ease-in forwards';
                setTimeout(() => {
                    if (message.parentNode) {
                        message.parentNode.removeChild(message);
                    }
                }, 300);
            }
        }, 5000);
    });
});

// Add slide out animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);

// Floating animation for product images
function addFloatingAnimation() {
    const productImages = document.querySelectorAll('.product-image, .logo-icon');
    
    productImages.forEach(image => {
        image.addEventListener('mouseenter', function() {
            this.style.animationPlayState = 'paused';
        });
        
        image.addEventListener('mouseleave', function() {
            this.style.animationPlayState = 'running';
        });
    });
}

// Initialize floating animations when DOM is loaded
document.addEventListener('DOMContentLoaded', addFloatingAnimation);

// Add sparkle effect to buttons
function addSparkleEffect() {
    const buttons = document.querySelectorAll('.btn-primary');
    
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            const sparkle = document.createElement('span');
            sparkle.className = 'sparkle';
            sparkle.style.position = 'absolute';
            sparkle.style.left = e.offsetX + 'px';
            sparkle.style.top = e.offsetY + 'px';
            sparkle.innerHTML = '✨';
            sparkle.style.pointerEvents = 'none';
            sparkle.style.animation = 'sparkle 1s ease-out forwards';
            
            this.appendChild(sparkle);
            
            setTimeout(() => {
                if (sparkle.parentNode) {
                    sparkle.parentNode.removeChild(sparkle);
                }
            }, 1000);
        });
    });
}

// Initialize sparkle effects
document.addEventListener('DOMContentLoaded', addSparkleEffect);

// Preload images for better performance
function preloadImages() {
    const images = [
        'https://i.postimg.cc/sxHztTWn/Chat-GPT-Image-Jul-27-2025-01-04-59-AM-1.png',
        'https://i.postimg.cc/ZYCMHYRP/gym.png'
    ];
    
    images.forEach(src => {
        const img = new Image();
        img.src = src;
    });
}

// Initialize image preloading
document.addEventListener('DOMContentLoaded', preloadImages);
