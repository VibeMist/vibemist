// Background Music Controller for VibeMist website
class BackgroundMusic {
    constructor() {
        this.audio = null;
        this.isPlaying = false;
        this.isInitialized = false;
        this.volume = 0.3; // 30% volume by default
        this.musicUrl = 'https://cdn.pixabay.com/download/audio/2024/04/18/audio_e8a4b3bbea.mp3?filename=inner-world-1-original-lyrics-335827.mp3';
        
        this.initMusic();
        this.createMusicControls();
    }
    
    initMusic() {
        try {
            this.audio = new Audio(this.musicUrl);
            this.audio.loop = true;
            this.audio.volume = this.volume;
            this.audio.preload = 'auto';
            
            // Handle audio events
            this.audio.addEventListener('canplaythrough', () => {
                this.isInitialized = true;
                console.log('Background music ready to play');
            });
            
            this.audio.addEventListener('error', (e) => {
                console.error('Background music error:', e);
                this.hideMusicControls();
            });
            
            this.audio.addEventListener('ended', () => {
                this.play(); // Loop the music
            });
            
        } catch (error) {
            console.error('Failed to initialize background music:', error);
        }
    }
    
    createMusicControls() {
        // Create floating music control button
        const controlContainer = document.createElement('div');
        controlContainer.id = 'musicControls';
        controlContainer.innerHTML = `
            <div class="music-control-btn" onclick="backgroundMusic.toggle()" title="Toggle Background Music">
                <span id="musicIcon">🎵</span>
            </div>
            <div class="volume-control" style="display: none;">
                <input type="range" id="volumeSlider" min="0" max="100" value="30" 
                       oninput="backgroundMusic.setVolume(this.value)">
            </div>
        `;
        
        // Add CSS styles
        const style = document.createElement('style');
        style.textContent = `
            #musicControls {
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 1000;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 10px;
            }
            
            .music-control-btn {
                width: 50px;
                height: 50px;
                background: linear-gradient(135deg, #4fc3f7, #29b6f6);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                box-shadow: 0 4px 15px rgba(79, 195, 247, 0.4);
                transition: all 0.3s ease;
                animation: pulse 2s infinite;
            }
            
            .music-control-btn:hover {
                transform: scale(1.1);
                box-shadow: 0 6px 20px rgba(79, 195, 247, 0.6);
            }
            
            .music-control-btn.playing {
                background: linear-gradient(135deg, #4caf50, #43a047);
                animation: none;
            }
            
            .music-control-btn.paused {
                background: linear-gradient(135deg, #f44336, #d32f2f);
                animation: pulse 2s infinite;
            }
            
            @keyframes pulse {
                0% { box-shadow: 0 4px 15px rgba(79, 195, 247, 0.4); }
                50% { box-shadow: 0 4px 25px rgba(79, 195, 247, 0.8); }
                100% { box-shadow: 0 4px 15px rgba(79, 195, 247, 0.4); }
            }
            
            #musicIcon {
                font-size: 24px;
                user-select: none;
            }
            
            .volume-control {
                background: rgba(0, 0, 0, 0.8);
                padding: 10px;
                border-radius: 10px;
                border: 1px solid rgba(79, 195, 247, 0.3);
            }
            
            #volumeSlider {
                width: 100px;
                height: 5px;
                background: rgba(79, 195, 247, 0.3);
                outline: none;
                border-radius: 5px;
            }
            
            #volumeSlider::-webkit-slider-thumb {
                appearance: none;
                width: 15px;
                height: 15px;
                background: #4fc3f7;
                border-radius: 50%;
                cursor: pointer;
            }
            
            /* Mobile responsiveness */
            @media (max-width: 768px) {
                #musicControls {
                    bottom: 15px;
                    right: 15px;
                }
                
                .music-control-btn {
                    width: 45px;
                    height: 45px;
                }
                
                #musicIcon {
                    font-size: 20px;
                }
            }
        `;
        
        document.head.appendChild(style);
        document.body.appendChild(controlContainer);
        
        // Add click event to show/hide volume control
        controlContainer.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.toggleVolumeControl();
        });
    }
    
    toggle() {
        if (!this.isInitialized) {
            console.log('Music not ready yet');
            return;
        }
        
        if (this.isPlaying) {
            this.pause();
        } else {
            this.play();
        }
    }
    
    play() {
        if (!this.audio) return;
        
        // Handle autoplay restrictions
        this.audio.play().then(() => {
            this.isPlaying = true;
            this.updateUI();
            console.log('Background music started');
        }).catch((error) => {
            console.log('Autoplay prevented. User interaction required.', error);
            // On first visit, user needs to interact first
        });
    }
    
    pause() {
        if (!this.audio) return;
        
        this.audio.pause();
        this.isPlaying = false;
        this.updateUI();
        console.log('Background music paused');
    }
    
    setVolume(value) {
        if (!this.audio) return;
        
        this.volume = value / 100;
        this.audio.volume = this.volume;
    }
    
    updateUI() {
        const icon = document.getElementById('musicIcon');
        const btn = document.querySelector('.music-control-btn');
        
        if (!icon || !btn) return;
        
        if (this.isPlaying) {
            icon.textContent = '🎵';
            btn.className = 'music-control-btn playing';
            btn.title = 'Pause Background Music';
        } else {
            icon.textContent = '🔇';
            btn.className = 'music-control-btn paused';
            btn.title = 'Play Background Music';
        }
    }
    
    toggleVolumeControl() {
        const volumeControl = document.querySelector('.volume-control');
        if (volumeControl) {
            volumeControl.style.display = volumeControl.style.display === 'none' ? 'block' : 'none';
        }
    }
    
    hideMusicControls() {
        const controls = document.getElementById('musicControls');
        if (controls) {
            controls.style.display = 'none';
        }
    }
    
    // Auto-start music when user interacts with page
    enableAutoStart() {
        const startMusic = () => {
            if (!this.isPlaying && this.isInitialized) {
                this.play();
            }
            document.removeEventListener('click', startMusic);
            document.removeEventListener('touchstart', startMusic);
        };
        
        document.addEventListener('click', startMusic);
        document.addEventListener('touchstart', startMusic);
    }
}

// Initialize background music when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    window.backgroundMusic = new BackgroundMusic();
    
    // Enable auto-start after first user interaction
    window.backgroundMusic.enableAutoStart();
});

// Global function for manual control
function toggleBackgroundMusic() {
    if (window.backgroundMusic) {
        window.backgroundMusic.toggle();
    }
}