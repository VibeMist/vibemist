// Payment page functionality

let selectedPaymentMethod = 'razorpay';

// Payment method selection
document.addEventListener('DOMContentLoaded', function() {
    const paymentMethods = document.querySelectorAll('.payment-method');
    const payBtn = document.getElementById('payBtn');
    const codBtn = document.getElementById('codBtn');
    const deliveryAmount = document.getElementById('deliveryAmount');
    const totalAmount = document.getElementById('totalAmount');
    
    // Get base values from template
    const baseSubtotal = parseFloat(window.paymentData?.subtotal || 129);
    const onlineDelivery = 50;
    const codDelivery = 90;
    
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            // Remove active class from all methods
            paymentMethods.forEach(m => m.classList.remove('active'));
            
            // Add active class to selected method
            this.classList.add('active');
            
            // Update radio button
            const radio = this.querySelector('input[type="radio"]');
            if (radio) {
                radio.checked = true;
                selectedPaymentMethod = radio.value;
            }
            
            // Update delivery charge and total based on payment method
            let newDelivery, newTotal;
            if (selectedPaymentMethod === 'cod') {
                newDelivery = codDelivery;
                newTotal = baseSubtotal + codDelivery;
                payBtn.style.display = 'none';
                codBtn.style.display = 'block';
            } else {
                newDelivery = onlineDelivery;
                newTotal = baseSubtotal + onlineDelivery;
                payBtn.style.display = 'block';
                codBtn.style.display = 'none';
            }
            
            // Update UI
            if (deliveryAmount) deliveryAmount.textContent = `₹${newDelivery}`;
            if (totalAmount) totalAmount.textContent = `₹${newTotal.toFixed(2)}`;
            if (payBtn) payBtn.textContent = `Pay ₹${newTotal.toFixed(2)}`;
        });
    });
});

// Initiate Razorpay payment
function initiatePayment() {
    if (!window.paymentData) {
        showFlashMessage('Payment data not available', 'error');
        return;
    }
    
    showLoading(true);
    
    const options = {
        key: window.paymentData.razorpayKeyId,
        amount: window.paymentData.amount,
        currency: 'INR',
        name: 'Gym Fresh',
        description: 'VibeMist Drop 1',
        order_id: window.paymentData.razorpayOrderId,
        prefill: {
            name: window.paymentData.customerName,
            email: window.paymentData.customerEmail,
            contact: window.paymentData.customerPhone
        },
        theme: {
            color: '#00ffff'
        },
        handler: function(response) {
            // Payment successful
            verifyPayment(response);
        },
        modal: {
            ondismiss: function() {
                showLoading(false);
                showFlashMessage('Payment cancelled', 'error');
            }
        }
    };
    
    try {
        const rzp = new Razorpay(options);
        rzp.open();
        showLoading(false);
    } catch (error) {
        console.error('Razorpay initialization error:', error);
        showLoading(false);
        showFlashMessage('Payment gateway initialization failed', 'error');
    }
}

// Verify payment with backend
function verifyPayment(response) {
    showLoading(true, 'Verifying payment...');
    
    const formData = new FormData();
    formData.append('razorpay_payment_id', response.razorpay_payment_id);
    formData.append('razorpay_order_id', response.razorpay_order_id);
    formData.append('razorpay_signature', response.razorpay_signature);
    
    fetch('/payment/verify', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        showLoading(false);
        
        if (data.success) {
            // Payment verified successfully
            showFlashMessage('Payment successful!', 'success');
            
            // Automatically send confirmation email for all successful payments
            sendOrderConfirmationEmail(data.order_id);
            
            // Redirect to confirmation page
            setTimeout(() => {
                window.location.href = '/confirmation';
            }, 1500);
        } else {
            showFlashMessage(data.message || 'Payment verification failed', 'error');
        }
    })
    .catch(error => {
        console.error('Payment verification error:', error);
        showLoading(false);
        showFlashMessage('Payment verification failed. Please contact support.', 'error');
    });
}

// Place COD order
function placeCODOrder() {
    showLoading(true, 'Placing your order...');
    
    fetch('/payment/cod', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        credentials: 'same-origin'  // Include session cookies
    })
    .then(response => {
        showLoading(false);
        if (response.ok && response.redirected) {
            // COD order placed successfully, automatically send email and redirect
            showFlashMessage('COD order placed successfully!', 'success');
            
            // Automatically send confirmation email for COD orders
            sendCODConfirmationEmail();
            
            setTimeout(() => {
                window.location.href = response.url;
            }, 1000);
        } else {
            // Try to redirect to confirmation anyway for COD orders
            showFlashMessage('COD order placed successfully!', 'success');
            
            // Automatically send confirmation email for COD orders
            sendCODConfirmationEmail();
            
            setTimeout(() => {
                window.location.href = '/confirmation';
            }, 1000);
        }
    })
    .catch(error => {
        console.error('COD order error:', error);
        showLoading(false);
        // Even if there's an error, try to show success since order was likely placed
        showFlashMessage('COD order placed! Redirecting to confirmation...', 'success');
        
        // Automatically send confirmation email for COD orders
        sendCODConfirmationEmail();
        
        setTimeout(() => {
            window.location.href = '/confirmation';
        }, 1500);
    });
}

// Show/hide loading overlay
function showLoading(show, message = 'Processing your payment...') {
    const overlay = document.getElementById('loadingOverlay');
    if (!overlay) return;
    
    if (show) {
        overlay.style.display = 'flex';
        const messageElement = overlay.querySelector('p');
        if (messageElement) {
            messageElement.textContent = message;
        }
    } else {
        overlay.style.display = 'none';
    }
}

// Send order confirmation email
function sendOrderConfirmationEmail(orderId) {
    if (typeof emailjs === 'undefined') {
        console.warn('EmailJS not available for confirmation email');
        return;
    }
    
    const templateParams = {
        to_email: window.paymentData.customerEmail,
        customer_name: window.paymentData.customerName,
        order_id: orderId,
        product_name: 'VibeMist Drop 1',
        total_amount: window.paymentData.amount / 100
    };
    
    const serviceId = 'service_t26fwjh';
    const templateId = 'template_dc8mx5l';
    
    emailjs.send(serviceId, templateId, templateParams)
        .then(function(response) {
            console.log('Confirmation email sent successfully');
        }, function(error) {
            console.error('Failed to send confirmation email:', error);
        });
}

// Send COD order confirmation email
function sendCODConfirmationEmail() {
    if (typeof emailjs === 'undefined') {
        console.warn('EmailJS not available for COD confirmation email');
        return;
    }
    
    if (!window.paymentData) {
        console.warn('Payment data not available for COD email');
        return;
    }
    
    const templateParams = {
        to_email: window.paymentData.customerEmail,
        customer_name: window.paymentData.customerName,
        order_id: 'Generating...', // COD orders get ID after creation
        product_name: 'VibeMist Drop 1',
        total_amount: (129 + 90) // COD total
    };
    
    const serviceId = 'service_t26fwjh';
    const templateId = 'template_dc8mx5l';
    
    emailjs.send(serviceId, templateId, templateParams)
        .then(function(response) {
            console.log('COD confirmation email sent successfully');
        }, function(error) {
            console.error('Failed to send COD confirmation email:', error);
        });
}

// Handle payment errors
function handlePaymentError(error) {
    console.error('Payment error:', error);
    showLoading(false);
    
    let errorMessage = 'Payment failed. Please try again.';
    
    if (error.code) {
        switch (error.code) {
            case 'PAYMENT_CANCELLED':
                errorMessage = 'Payment was cancelled';
                break;
            case 'PAYMENT_TIMEOUT':
                errorMessage = 'Payment timed out. Please try again.';
                break;
            case 'NETWORK_ERROR':
                errorMessage = 'Network error. Please check your connection.';
                break;
            default:
                errorMessage = `Payment failed: ${error.description || error.message}`;
        }
    }
    
    showFlashMessage(errorMessage, 'error');
}

// Back button functionality
function goBack() {
    if (window.history.length > 1) {
        window.history.back();
    } else {
        window.location.href = '/checkout';
    }
}

// Payment security features
function validatePaymentEnvironment() {
    // Check if page is served over HTTPS in production
    if (location.protocol !== 'https:' && location.hostname !== 'localhost') {
        showFlashMessage('This page requires a secure connection', 'error');
        return false;
    }
    
    // Check if Razorpay is loaded
    if (typeof Razorpay === 'undefined') {
        showFlashMessage('Payment gateway not loaded. Please refresh the page.', 'error');
        return false;
    }
    
    return true;
}

// Initialize payment page
document.addEventListener('DOMContentLoaded', function() {
    // Validate payment environment
    if (!validatePaymentEnvironment()) {
        return;
    }
    
    // Add keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const overlay = document.getElementById('loadingOverlay');
            if (overlay && overlay.style.display === 'flex') {
                showLoading(false);
            }
        }
    });
    
    // Auto-focus on payment method selection
    const firstPaymentMethod = document.querySelector('.payment-method input[type="radio"]:checked');
    if (firstPaymentMethod) {
        firstPaymentMethod.focus();
    }
    
    // Add accessibility improvements
    const paymentMethods = document.querySelectorAll('.payment-method');
    paymentMethods.forEach(method => {
        method.setAttribute('role', 'button');
        method.setAttribute('tabindex', '0');
        
        method.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.click();
            }
        });
    });
});

// Prevent form resubmission on page refresh
window.addEventListener('beforeunload', function() {
    showLoading(false);
});

// Handle offline/online status
window.addEventListener('offline', function() {
    showFlashMessage('You are offline. Payment functionality may not work.', 'error');
});

window.addEventListener('online', function() {
    showFlashMessage('Connection restored', 'success');
});
