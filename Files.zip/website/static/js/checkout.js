// Checkout page functionality

// Quantity change functionality
function changeQuantity(delta) {
    const quantityInput = document.getElementById('quantity');
    const currentQuantity = parseInt(quantityInput.value) || 1;
    const newQuantity = Math.max(1, Math.min(10, currentQuantity + delta));
    
    quantityInput.value = newQuantity;
    updateOrderSummary(newQuantity);
}

// Update order summary based on quantity
function updateOrderSummary(quantity) {
    const basePrice = 129;
    const subtotal = basePrice * quantity;
    const total = subtotal; // Base price only, delivery calculated separately
    
    const subtotalElement = document.getElementById('subtotal');
    const totalElement = document.getElementById('total');
    
    if (subtotalElement) {
        subtotalElement.textContent = `₹${subtotal}`;
    }
    
    if (totalElement) {
        totalElement.textContent = `₹${total} + delivery`;
    }
}

// Form validation
function validateForm() {
    const form = document.getElementById('checkoutForm');
    const requiredFields = form.querySelectorAll('input[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        const errorElement = field.parentNode.querySelector('.error-message');
        
        // Remove existing error message
        if (errorElement) {
            errorElement.remove();
        }
        
        // Validate field
        if (!field.value.trim()) {
            showFieldError(field, 'This field is required');
            isValid = false;
        } else {
            // Additional validation based on field type
            if (field.type === 'email' && !isValidEmail(field.value)) {
                showFieldError(field, 'Please enter a valid email address');
                isValid = false;
            } else if (field.type === 'tel' && !isValidPhone(field.value)) {
                showFieldError(field, 'Please enter a valid phone number');
                isValid = false;
            } else if (field.name === 'pincode' && !isValidPincode(field.value)) {
                showFieldError(field, 'Please enter a valid PIN code');
                isValid = false;
            }
        }
    });
    
    return isValid;
}

// Show field error message
function showFieldError(field, message) {
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.textContent = message;
    errorElement.style.color = '#ff4444';
    errorElement.style.fontSize = '0.85rem';
    errorElement.style.marginTop = '0.25rem';
    
    field.parentNode.appendChild(errorElement);
    field.style.borderColor = '#ff4444';
}

// Validation helper functions
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPhone(phone) {
    const phoneRegex = /^[\+]?[1-9][\d]{9,15}$/;
    return phoneRegex.test(phone.replace(/[\s\-\(\)]/g, ''));
}

function isValidPincode(pincode) {
    const pincodeRegex = /^[1-9][0-9]{5}$/;
    return pincodeRegex.test(pincode);
}

// Form submission handling
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('checkoutForm');
    
    if (form) {
        form.addEventListener('submit', function(e) {
            if (!validateForm()) {
                e.preventDefault();
                showFlashMessage('Please correct the errors in the form', 'error');
                return false;
            }
            
            // Show loading state
            const submitButton = form.querySelector('button[type="submit"]');
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.textContent = 'Processing...';
            }
        });
        
        // Real-time validation
        const inputs = form.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            input.addEventListener('input', function() {
                // Clear error styling on input
                this.style.borderColor = '';
                const errorElement = this.parentNode.querySelector('.error-message');
                if (errorElement) {
                    errorElement.remove();
                }
            });
        });
    }
    
    // Initialize quantity
    const quantityInput = document.getElementById('quantity');
    if (quantityInput) {
        updateOrderSummary(parseInt(quantityInput.value) || 1);
    }
});

// Validate individual field
function validateField(field) {
    const errorElement = field.parentNode.querySelector('.error-message');
    
    // Remove existing error message
    if (errorElement) {
        errorElement.remove();
    }
    
    field.style.borderColor = '';
    
    if (field.hasAttribute('required') && !field.value.trim()) {
        showFieldError(field, 'This field is required');
        return false;
    }
    
    // Type-specific validation
    if (field.type === 'email' && field.value && !isValidEmail(field.value)) {
        showFieldError(field, 'Please enter a valid email address');
        return false;
    }
    
    if (field.type === 'tel' && field.value && !isValidPhone(field.value)) {
        showFieldError(field, 'Please enter a valid phone number');
        return false;
    }
    
    if (field.name === 'pincode' && field.value && !isValidPincode(field.value)) {
        showFieldError(field, 'Please enter a valid PIN code');
        return false;
    }
    
    return true;
}

// Auto-format phone number
function formatPhoneNumber(input) {
    let value = input.value.replace(/\D/g, '');
    
    if (value.length >= 10) {
        value = value.substring(0, 10);
        value = value.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
    }
    
    input.value = value;
}

// Auto-format PIN code
function formatPincode(input) {
    let value = input.value.replace(/\D/g, '');
    
    if (value.length > 6) {
        value = value.substring(0, 6);
    }
    
    input.value = value;
}

// Add formatting to appropriate fields
document.addEventListener('DOMContentLoaded', function() {
    const phoneInput = document.getElementById('customer_phone');
    const pincodeInput = document.getElementById('pincode');
    
    if (phoneInput) {
        phoneInput.addEventListener('input', function() {
            formatPhoneNumber(this);
        });
    }
    
    if (pincodeInput) {
        pincodeInput.addEventListener('input', function() {
            formatPincode(this);
        });
    }
});

// Auto-save form data to localStorage
function saveFormData() {
    const form = document.getElementById('checkoutForm');
    if (!form) return;
    
    const formData = new FormData(form);
    const data = {};
    
    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }
    
    localStorage.setItem('checkoutFormData', JSON.stringify(data));
}

// Load saved form data
function loadFormData() {
    const savedData = localStorage.getItem('checkoutFormData');
    if (!savedData) return;
    
    try {
        const data = JSON.parse(savedData);
        const form = document.getElementById('checkoutForm');
        
        if (form) {
            Object.keys(data).forEach(key => {
                const input = form.querySelector(`[name="${key}"]`);
                if (input && !input.value) {
                    input.value = data[key];
                }
            });
        }
    } catch (e) {
        console.error('Error loading saved form data:', e);
    }
}

// Initialize auto-save functionality
document.addEventListener('DOMContentLoaded', function() {
    loadFormData();
    
    const form = document.getElementById('checkoutForm');
    if (form) {
        const inputs = form.querySelectorAll('input, select');
        inputs.forEach(input => {
            input.addEventListener('change', saveFormData);
        });
    }
});

// Clear saved data on successful submission
window.addEventListener('beforeunload', function() {
    // Only clear if we're navigating to payment page
    if (window.location.href.includes('/payment')) {
        localStorage.removeItem('checkoutFormData');
    }
});
