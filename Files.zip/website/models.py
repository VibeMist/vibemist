from app import db
from datetime import datetime
import uuid

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.String(50), unique=True, nullable=False, default=lambda: str(uuid.uuid4())[:8].upper())
    customer_name = db.Column(db.String(100), nullable=False)
    customer_email = db.Column(db.String(120), nullable=False)
    customer_phone = db.Column(db.String(20), nullable=False)
    
    # Address fields
    address_line_1 = db.Column(db.String(200), nullable=False)
    address_line_2 = db.Column(db.String(200))
    city = db.Column(db.String(100), nullable=False)
    state = db.Column(db.String(100), nullable=False)
    pincode = db.Column(db.String(10), nullable=False)
    country = db.Column(db.String(100), nullable=False, default='India')
    
    # Product details
    product_name = db.Column(db.String(200), nullable=False, default='VibeMist Drop 1')
    quantity = db.Column(db.Integer, nullable=False, default=1)
    price = db.Column(db.Float, nullable=False, default=129.0)
    
    # Order status
    status = db.Column(db.String(50), nullable=False, default='pending')  # pending, paid, shipped, delivered, cancelled
    payment_method = db.Column(db.String(20), nullable=False, default='online')  # online, cod
    payment_id = db.Column(db.String(100))
    razorpay_order_id = db.Column(db.String(100))
    
    # Timestamps
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'order_id': self.order_id,
            'customer_name': self.customer_name,
            'customer_email': self.customer_email,
            'customer_phone': self.customer_phone,
            'address_line_1': self.address_line_1,
            'address_line_2': self.address_line_2,
            'city': self.city,
            'state': self.state,
            'pincode': self.pincode,
            'country': self.country,
            'product_name': self.product_name,
            'quantity': self.quantity,
            'price': self.price,
            'status': self.status,
            'payment_id': self.payment_id,
            'razorpay_order_id': self.razorpay_order_id,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
