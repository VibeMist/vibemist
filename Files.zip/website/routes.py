from flask import render_template, request, redirect, url_for, session, jsonify, flash
from app import app, db
from models import Order
from email_service import send_simple_email, create_gmail_draft_link
import razorpay
import os
import logging

# Initialize Razorpay client
razorpay_client = razorpay.Client(auth=(
    os.environ.get("RAZORPAY_KEY_ID", "rzp_test_key"),
    os.environ.get("RAZORPAY_KEY_SECRET", "rzp_test_secret")
))

@app.route('/')
def index():
    """Main landing page"""
    return render_template('index.html')

@app.route('/order')
def start_order():
    """Start the ordering process"""
    # Clear any existing order data from session
    session.pop('order_data', None)
    return redirect(url_for('checkout'))

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    """Checkout page with address collection"""
    if request.method == 'POST':
        try:
            # Collect form data
            order_data = {
                'customer_name': request.form.get('customer_name'),
                'customer_email': request.form.get('customer_email'),
                'customer_phone': request.form.get('customer_phone'),
                'address_line_1': request.form.get('address_line_1'),
                'address_line_2': request.form.get('address_line_2'),
                'city': request.form.get('city'),
                'state': request.form.get('state'),
                'pincode': request.form.get('pincode'),
                'country': request.form.get('country', 'India'),
                'quantity': int(request.form.get('quantity', 1))
            }
            
            # Validate required fields
            required_fields = ['customer_name', 'customer_email', 'customer_phone', 
                             'address_line_1', 'city', 'state', 'pincode']
            for field in required_fields:
                if not order_data.get(field):
                    flash(f'{field.replace("_", " ").title()} is required', 'error')
                    return render_template('checkout.html', form_data=order_data)
            
            # Store in session
            session['order_data'] = order_data
            
            return redirect(url_for('payment'))
            
        except Exception as e:
            logging.error(f"Checkout error: {str(e)}")
            flash('An error occurred. Please try again.', 'error')
            return render_template('checkout.html')
    
    return render_template('checkout.html')

@app.route('/payment')
def payment():
    """Payment page with Razorpay integration"""
    order_data = session.get('order_data')
    if not order_data:
        flash('Please complete the checkout process first', 'error')
        return redirect(url_for('checkout'))
    
    try:
        # Calculate total amount
        base_price = 129.0
        delivery_charge = 50.0  # Online payment delivery charge
        quantity = order_data.get('quantity', 1)
        subtotal = base_price * quantity
        total_amount = subtotal + delivery_charge
        
        # Create Razorpay order
        razorpay_order = razorpay_client.order.create({
            'amount': int(total_amount * 100),  # Amount in paise
            'currency': 'INR',
            'payment_capture': '1'
        })
        
        # Store Razorpay order ID in session
        session['razorpay_order_id'] = razorpay_order['id']
        
        payment_data = {
            'order_data': order_data,
            'total_amount': total_amount,
            'razorpay_order_id': razorpay_order['id'],
            'razorpay_key_id': os.environ.get("RAZORPAY_KEY_ID", "rzp_test_key")
        }
        
        payment_data.update({
            'online_delivery': 50,
            'cod_delivery': 90,
            'base_price': base_price,
            'subtotal': subtotal
        })
        
        return render_template('payment.html', **payment_data)
        
    except Exception as e:
        logging.error(f"Payment setup error: {str(e)}")
        flash('Payment setup failed. Please try again.', 'error')
        return redirect(url_for('checkout'))

@app.route('/payment/verify', methods=['POST'])
def verify_payment():
    """Verify Razorpay payment and create order"""
    try:
        # Get payment details from request
        payment_id = request.form.get('razorpay_payment_id')
        order_id = request.form.get('razorpay_order_id')
        signature = request.form.get('razorpay_signature')
        
        # Verify payment signature
        params_dict = {
            'razorpay_order_id': order_id,
            'razorpay_payment_id': payment_id,
            'razorpay_signature': signature
        }
        
        razorpay_client.utility.verify_payment_signature(params_dict)
        
        # Get order data from session
        order_data = session.get('order_data')
        if not order_data:
            return jsonify({'success': False, 'message': 'Order data not found'})
        
        # Create order in database
        order = Order(
            customer_name=order_data['customer_name'],
            customer_email=order_data['customer_email'],
            customer_phone=order_data['customer_phone'],
            address_line_1=order_data['address_line_1'],
            address_line_2=order_data.get('address_line_2'),
            city=order_data['city'],
            state=order_data['state'],
            pincode=order_data['pincode'],
            country=order_data['country'],
            quantity=order_data['quantity'],
            price=subtotal + delivery_charge,
            status='paid',
            payment_method='online',
            payment_id=payment_id,
            razorpay_order_id=order_id
        )
        
        db.session.add(order)
        db.session.commit()
        
        # Log email content as backup (in case EmailJS fails)
        try:
            email_content = send_simple_email(order_data, order_data['customer_email'])
            gmail_link = create_gmail_draft_link(order_data, order_data['customer_email'])
            logging.info(f"Gmail compose link: {gmail_link}")
        except Exception as e:
            logging.error(f"Alternative email logging failed: {str(e)}")
        
        # Store order ID in session for confirmation page
        session['confirmed_order_id'] = order.order_id
        
        # Clear order data from session
        session.pop('order_data', None)
        session.pop('razorpay_order_id', None)
        
        return jsonify({'success': True, 'order_id': order.order_id, 'send_email': True})
        
    except Exception as e:
        logging.error(f"Payment verification error: {str(e)}")
        return jsonify({'success': False, 'message': 'Payment verification failed'})

@app.route('/payment/cod', methods=['POST'])
def cash_on_delivery():
    """Process Cash on Delivery order"""
    try:
        # Get order data from session
        order_data = session.get('order_data')
        if not order_data:
            flash('Please complete the checkout process first', 'error')
            return redirect(url_for('checkout'))
        
        # Calculate total with COD delivery charge
        base_price = 129.0
        cod_delivery_charge = 90.0
        quantity = order_data.get('quantity', 1)
        subtotal = base_price * quantity
        total_amount = subtotal + cod_delivery_charge
        
        # Create order in database with COD status
        order = Order(
            customer_name=order_data['customer_name'],
            customer_email=order_data['customer_email'],
            customer_phone=order_data['customer_phone'],
            address_line_1=order_data['address_line_1'],
            address_line_2=order_data.get('address_line_2'),
            city=order_data['city'],
            state=order_data['state'],
            pincode=order_data['pincode'],
            country=order_data['country'],
            quantity=order_data['quantity'],
            price=total_amount,
            status='pending',  # COD orders start as pending
            payment_method='cod'
        )
        
        db.session.add(order)
        db.session.commit()
        
        # Log email content as backup (in case EmailJS fails)
        try:
            email_content = send_simple_email(order_data, order_data['customer_email'])
            gmail_link = create_gmail_draft_link(order_data, order_data['customer_email'])
            logging.info(f"Gmail compose link: {gmail_link}")
        except Exception as e:
            logging.error(f"Alternative email logging failed: {str(e)}")
        
        # Store order ID in session for confirmation page
        session['confirmed_order_id'] = order.order_id
        
        # Store flag to send email automatically
        session['send_email'] = True
        
        # Clear order data from session
        session.pop('order_data', None)
        session.pop('razorpay_order_id', None)
        
        return redirect(url_for('confirmation'))
    
    except Exception as e:
        logging.error(f"COD order creation error: {str(e)}")
        flash('Order creation failed. Please try again.', 'error')
        return redirect(url_for('checkout'))

@app.route('/confirmation')
def confirmation():
    """Order confirmation page"""
    order_id = session.get('confirmed_order_id')
    if not order_id:
        flash('Order not found', 'error')
        return redirect(url_for('index'))
    
    order = Order.query.filter_by(order_id=order_id).first()
    if not order:
        flash('Order not found', 'error')
        return redirect(url_for('index'))
    
    # Clear the email flag after use
    send_email_flag = session.pop('send_email', False)
    
    return render_template('confirmation.html', order=order)

@app.route('/track/<order_id>')
def track_order(order_id):
    """Track order status"""
    order = Order.query.filter_by(order_id=order_id).first()
    if not order:
        flash('Order not found', 'error')
        return redirect(url_for('index'))
    
    return render_template('confirmation.html', order=order, tracking=True)

@app.route('/email-alternatives/<order_id>')
def email_alternatives(order_id):
    """Show email alternatives for manual sending"""
    order = Order.query.filter_by(order_id=order_id).first()
    
    if not order:
        flash('Order not found.', 'error')
        return redirect(url_for('index'))
    
    # Create order data for email templates
    order_data = {
        'order_id': order.order_id,
        'customer_name': order.customer_name,
        'customer_email': order.customer_email,
        'customer_phone': order.customer_phone,
        'address_line_1': order.address_line_1,
        'address_line_2': order.address_line_2,
        'city': order.city,
        'state': order.state,
        'pincode': order.pincode,
        'country': 'India',
        'product_name': 'VibeMist Drop 1',
        'quantity': 1,
        'price': float(order.price),
        'payment_method': order.payment_method
    }
    
    # Generate email content and links
    email_content = send_simple_email(order_data, order.customer_email)
    gmail_link = create_gmail_draft_link(order_data, order.customer_email)
    
    from email_service import get_whatsapp_message
    whatsapp_message = get_whatsapp_message(order_data)
    
    return render_template('email_alternatives.html', 
                         order=order,
                         email_content=email_content,
                         gmail_link=gmail_link,
                         whatsapp_message=whatsapp_message,
                         customer_email=order.customer_email,
                         customer_phone=order.customer_phone)

@app.errorhandler(404)
def not_found_error(error):
    return render_template('index.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('index.html'), 500
